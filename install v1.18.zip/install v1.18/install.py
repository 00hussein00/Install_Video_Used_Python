import pytube as pt
import time


name = time.time()

print('\t\t\t\tDownload from youtube with the Url\n\n\n')
print( " if you need download audio and video enter 1 ")
print( " if you need download video enter 2 ")
print( " if you need download audio enter 3 ")
ope = int(input('enter operation : '))


if ope != 2: 
    url = input('enter the url  : ')

def download_audio(url):
    name = time.time()
    pt.YouTube(url).streams.get_audio_only().download('D://dawnlod//install as python',filename=(f'{name}.mp3'))
    print('completely download audio')


def download_video_h(url):
    name = time.time()
    pt.YouTube(url).streams.get_highest_resolution().download('D://dawnlod//install as python',filename=(f'{name}.mp4'))
    print('completely download highest video')

def download_video_l(url):
    name = time.time()
    pt.YouTube(url).streams.get_lowest_resolution().download('D://dawnlod//install as python',filename=(f'{name}.mp4'))
    print('completely download lowest video')
    
    
    
  
    
if ope == 1:
    download_audio(url)  
    download_video_h(url)
    
elif ope == 2:
    print("\n\nif you need download highest video enter 1 \n")
    print("if you need download lowest video enter 2 ")
    ope1 = int(input('enter operation : '))
    url = input('enter the url  : ')
    if ope1 == 1:
        download_video_h(url)
    elif ope1== 2:
        download_video_l(url)
        
    else:
        print('Error')  
    
elif ope ==3:
    download_audio(url) 

else:
    print('Error')  
    
#pt.YouTube(url).streams.get_highest_resolution().download('D://dawnlod')

print("\t\t\t\t\t\t\t\n\n\ncompletely download ")


 






