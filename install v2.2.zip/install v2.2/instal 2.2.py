import pytube as pt
from tkinter import * 
from tkinter  import filedialog #get custom path

path = 'D://dawnlod//install as python' # default  path


form1 = Tk()
form1.title("install use python") #titel fo prongram
form1.geometry('600x200') #size of program

lbl = Label(form1,text='URL : ').grid(row = 0,column=0)    #lbl url
txt = Text(form1,height = 1,width = 40) #add url

lblE = Label(form1,text='').grid(row=1,column=0) #Empty label for design

lbl2 = Label(form1,text='name : ').grid(row=2,column=0) #lbl name
txt2 = Text(form1,height = 1,width = 40) #add new name to video if check box is checked

lblE1 = Label(form1,text='').grid(row=3)  #Empty label for design


lbl3=Label(form1,text='') # lbl to show if install is completed


lblE2 = Label(form1,text='').grid(row=5)#Empty label for design
lblE3 = Label(form1,text='').grid(row=8)#Empty label for design



def getUrl(): #functhin to get url from txt
    inp = txt.get("1.0","end-1c")
    return inp

def getName(): #functhin to get a new name from txt2
    inp = txt2.get("1.0","end-1c")
    return inp    



def get_path(): #function to set a  path for download
    new_path = filedialog.askdirectory()
    return new_path
    

def download_audio():# doenload Audio 
        if getVar1() == 0 and getVar3() == 0: # don't need to change any thing
            pt.YouTube(getUrl()).streams.get_audio_only().download(f'{path}')

        elif getVar1() == 1 and getVar3() == 1 : # need to change name and path

            pt.YouTube(getUrl()).streams.get_audio_only().download(f'{get_path()}',filename=(f'{getName()}.mp3'))
        
        elif getVar1() == 1 and getVar3() == 0 : # need change name but not path
        
            pt.YouTube(getUrl()).streams.get_audio_only().download(f'{path}',filename=(f'{getName()}.mp3'))
        
        elif getVar1() == 0 and getVar3() == 1 :  # need change path but not name
            
            pt.YouTube(getUrl()).streams.get_audio_only().download(f'{get_path()}')
            
        lbl3.config(text ='completely download audio' )  # show meesage if install is done
        print('completely download audio')


    
def download_video_h():# doenload video highest resolution
    if getVar1() == 0 and getVar3() == 0: # don't need to change any thing
        pt.YouTube(getUrl()).streams.get_highest_resolution().download(f'{path}')

    elif getVar1() == 1 and getVar3() == 1 : # need to change name and path

        pt.YouTube(getUrl()).streams.get_highest_resolution().download(f'{get_path()}',filename=(f'{getName()}.mp4'))
    
    elif getVar1() == 1 and getVar3() == 0 : # need change name but not path
    
        pt.YouTube(getUrl()).streams.get_highest_resolution().download(f'{path}',filename=(f'{getName()}.mp4'))
    
    elif getVar1() == 0 and getVar3() == 1 :  # need change path but not name
        
        pt.YouTube(getUrl()).streams.get_highest_resolution().download(f'{get_path()}')
        
    
    lbl3.config(text ='completely download highest video' ) # show meesage if install is done
    print('completely download highest video')
    
    
def download_video_l(): # doenload video lowest resolution
    
    if getVar1() == 0 and getVar3() == 0: # don't need to change any thing
        pt.YouTube(getUrl()).streams.get_lowest_resolution().download(f'{path}')

    elif getVar1() == 1 and getVar3() == 1 : # need to change name and path

        pt.YouTube(getUrl()).streams.get_lowest_resolution().download(f'{get_path()}',filename=(f'{getName()}.mp4'))
    
    elif getVar1() == 1 and getVar3() == 0 : # need change name but not path
    
        pt.YouTube(getUrl()).streams.get_lowest_resolution().download(f'{path}',filename=(f'{getName()}.mp4'))
    
    elif getVar1() == 0 and getVar3() == 1 :  # need change path but not name
        
        pt.YouTube(getUrl()).streams.get_lowest_resolution().download(f'{get_path()}')
        
    lbl3.config(text ='completely download lowest video' ) # show meesage if install is done
    print('completely download lowest video')


    

btn = Button(form1,text='Install Highest Video' ,command= download_video_h) # btn used to install highest Video
btn1 = Button(form1,text='Install Lowest Video' ,command= download_video_l)   # btn used to install  lowest Video
btn2 = Button(form1,text='Install Audio' ,command= download_audio)       # btn used to install audio only



var1 = IntVar() # checked var1 = 1 #not checked var1 = 0

var3 = IntVar() # checked var3 = 1 ##not checked var3 = 0


chbox1 =Checkbutton(form1,variable=var1,text='change name').grid(row=2,column=2)#,activebackground='blue',activeforeground='red', command=display_input
chbox2 =Checkbutton(form1,variable=var3,text='change path').grid(row=3,column=2)#,activebackground='blue',activeforeground='red', command=display_input

def getVar1(): #function to checked if checkbox 1 is checked
    return var1.get() # return a value of var1 

def getVar3(): #function to checked if checkbox 2 is checked
    return var3.get() # return a value of var3









txt.grid(row=0,column=1) #show the box for add url

lbl3.grid(row=10) # show the install is completed 

txt2.grid(row=2,column=1) #the new name of video

btn.grid(row=6,column=0) # show the btn for install highest Video

btn1.grid(row=6,column=1) # show the btn for install  lowest Video

btn2.grid(row=6,column=2) # show the btn for install audio only







form1.mainloop()  # to run a program







