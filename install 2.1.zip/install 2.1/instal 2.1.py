# -*- coding: utf-8 -*-
"""
Created on Sat Jan  7 18:06:49 2023

@author: user
"""

import pytube as pt

from tkinter import * 





form1 = Tk()
form1.title("install use python")
form1.geometry('500x200')
lbl = Label(form1,text='URL : ')
txt = Text(form1,height = 1,width = 25)

lbl2 = Label(form1,text='name : ')
txt2 = Text(form1,height = 1,width = 25) 

lbl3 = Label(form1,text='')




## empty lbl 
lblE = Label(form1,text='')
lblE1 = Label(form1,text='')
lblE2 = Label(form1,text='')
lblE3 = Label(form1,text='')
lblE4 = Label(form1,text='')



def getUrl():
    inp = txt.get("1.0","end-1c")
    return inp

def getName():
    inp = txt2.get("1.0","end-1c")
    return inp    

def getLoc():
    inp = txt3.get("1.0","end-1c")
    return inp


def download_audio(url):
    if getVar1() == 0 :
        pt.YouTube(url).streams.get_audio_only().download('D://dawnlod//install as python//Audio')
    else :
        pt.YouTube(url).streams.get_audio_only().download('D://dawnlod//install as python//Audio',filename=(f'{getName()}.mp3'))
    
    lbl3.config(text ='completely download audio' )
    print('completely download audio')


def download_video_h(url):
    if getVar1() == 0 :
        pt.YouTube(url).streams.get_highest_resolution().download('D://dawnlod//install as python//video')
    else :
        pt.YouTube(url).streams.get_highest_resolution().download('D://dawnlod//install as python//video',filename=(f'{getName()}.mp4'))
    print('completely download highest video')
    lbl3.config(text ='completely download highest video' )


def download_video_l(url):
    if getVar1() == 0 :
        pt.YouTube(url).streams.get_lowest_resolution().download('D://dawnlod//install as python//video')
    else :
        pt.YouTube(url).streams.get_lowest_resolution().download('D://dawnlod//install as python//video',filename=(f'{getName()}.mp4'))

    lbl3.config(text ='completely download lowest video' )
    print('completely download lowest video')

def odownload_video_l(url):
    pt.YouTube(url).streams.get_lowest_resolution().download('D://dawnlod//install as python//video')
    print('completely download lowest video')

    
def DH():
    return download_video_h(getUrl())
def Dl():
    return download_video_l(getUrl())
def DA():
    return download_audio(getUrl())
def DD():
    DA()
    DH()


btn = Button(form1,text='install highest Video' ,command= DH)
btn1 = Button(form1,text='install lowest Video' ,command= Dl)   
btn2 = Button(form1,text='install audio only' ,command= DA)       
btn3 = Button(form1,text='install' ,command= DD)

var1 = IntVar() # checked var1 = 1
var2 = IntVar() #not checked var2 = 0
  

def getVar1():
    return var1.get()


chbox1 =Checkbutton(form1,variable=var1,text='change name').grid(row=2,column=2)#,activebackground='blue',activeforeground='red', command=display_input


lbl.grid(row = 0,column=0)
txt.grid(row=0,column=1)

lblE.grid(row=1,column=0)
lbl2.grid(row=2,column=0)
txt2.grid(row=2,column=1)
lblE2.grid(row=3)

#lblE.grid(row=5,column=0)
lblE1.grid(row=5)


btn.grid(row=6,column=0)
btn1.grid(row=6,column=1)
btn2.grid(row=6,column=2)
lblE2.grid(row=8)
lblE3.grid(row=8)
btn3.grid(row=9,column=1)

lbl3.grid(row=10)



























form1.mainloop()











